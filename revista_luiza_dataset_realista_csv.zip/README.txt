Dataset sintético - Revista Luiza S.A. (versão realista)

Arquivos incluídos:
- clientes.csv
- categorias.csv
- produtos.csv
- lojas.csv
- pedidos.csv
- itens_pedido.csv
- entregas.csv
- dicionario_dados.csv

Resumo:
- 5000 clientes
- 15 categorias
- 800 produtos
- 45 lojas/CDs/dark stores
- 10000 pedidos
- 20045 itens de pedido
- 10000 entregas

Indicadores desta versão:
- Ticket médio: R$ 1088.30
- Receita total: R$ 10883018.76
- Maior pedido: R$ 4004.17

Observações:
- Separador ; 
- Encoding UTF-8 com BOM
- Período: 2023-01-01 a 2025-12-31
- Valores financeiros calibrados para varejo brasileiro, evitando tickets irreais.
